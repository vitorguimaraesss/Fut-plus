fut+ - PWA streaming scaffold (manual PIX verification)

Admin credentials (default):
  user: fut+
  pass: 8786

PIX:
  chave (celular): 21967619932
  nome: João Vitor Guimarães Porto
  banco: Nubank
  valor: R$ 10.99

How to run locally:
1. Install Node 18+
2. npm install
3. node server.js
4. Open http://localhost:3000

Deploy to Render.com:
- Create repo, push this project.
- New Web Service on Render -> connect repo -> build: npm install -> start: npm start
- Set environment variables (JWT_SECRET, ADMIN_USER, ADMIN_PASS, PIX_KEY, SUBS_PRICE, FUTEMAIS_URL)

Notes:
- Uploaded receipts saved in /uploads
- DB: data.db (SQLite). For production use managed Postgres.
- You must confirm users' receipts manually via admin endpoint /admin/receipts and POST /admin/confirm
