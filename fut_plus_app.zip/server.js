/*
  fut+ server (manual PIX verification)
  - Admin user: fut+ / 8786 (default, configurable via ADMIN_USER / ADMIN_PASS env vars)
  - PIX key: 21967619932
  - Price: R$ 10.99
  - Use: node server.js
  - Install: npm install express multer sqlite3 sqlite jsonwebtoken body-parser node-fetch
*/

import express from 'express';
import bodyParser from 'body-parser';
import jwt from 'jsonwebtoken';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import fetch from 'node-fetch';
import multer from 'multer';
import path from 'path';
import fs from 'fs';

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_THIS';
const ADMIN_USER = process.env.ADMIN_USER || 'fut+';
const ADMIN_PASS = process.env.ADMIN_PASS || '8786';
const PIX_KEY = process.env.PIX_KEY || '21967619932';
const SUBS_PRICE = process.env.SUBS_PRICE || '10.99';
const FUTEMAIS = process.env.FUTEMAIS_URL || 'https://futemais.app/app2/';

const uploadDir = './uploads';
if(!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
const storage = multer.diskStorage({ destination: uploadDir, filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname) });
const upload = multer({ storage });

const db = await open({ filename: './data.db', driver: sqlite3.Database });
await db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE, pass TEXT, active INTEGER DEFAULT 0, expires_at TEXT)`);
await db.exec(`CREATE TABLE IF NOT EXISTS receipts(id INTEGER PRIMARY KEY, user_id INTEGER, filename TEXT, amount REAL, status TEXT, created_at TEXT)`);

function genToken(payload){ return jwt.sign(payload, JWT_SECRET, {expiresIn:'7d'}); }
function verifyToken(token){ try{return jwt.verify(token, JWT_SECRET);}catch(e){return null;} }

app.post('/api/register', async (req,res)=>{
  const {email,pass} = req.body;
  try{
    const info = await db.run('INSERT INTO users(email,pass) VALUES(?,?)',[email,pass]);
    const token = genToken({id:info.lastID,email});
    return res.json({token});
  }catch(err){ return res.status(400).json({error:'email exists'}); }
});

app.post('/api/login', async (req,res)=>{
  const {email,pass} = req.body;
  const u = await db.get('SELECT * FROM users WHERE email=? AND pass=?',[email,pass]);
  if(!u) return res.status(401).end();
  const token = genToken({id:u.id,email});
  res.json({token});
});

// list games (scrape futemais page)
app.get('/api/games', async (req,res)=>{
  try{
    const r = await fetch(FUTEMAIS);
    const html = await r.text();
    const games = [];
    const re = /<a[^>]+href=["']([^"']+)["'][^>]*>([^<]+)<\/a>/gi;
    let m; let id=1;
    while((m = re.exec(html)) !== null && games.length < 50){
      const href = m[1];
      const title = m[2].trim();
      if(href.includes('futemais.app') || href.includes('links3.')){
        games.push({id:id++, title, origin_url: href});
      }
    }
    if(games.length===0) games.push({id:1,title:'Demo Jogo', origin_url:''});
    res.json(games);
  }catch(err){ console.error(err); res.status(500).json({error:'failed to fetch source'}); }
});

// upload receipt (user)
app.post('/upload_receipt', upload.single('receipt'), async (req,res)=>{
  const auth = req.headers.authorization?.split(' ')[1];
  const user = auth ? verifyToken(auth) : null;
  if(!user) return res.status(401).json({error:'login required'});
  const u = await db.get('SELECT * FROM users WHERE id=?',[user.id]);
  if(!u) return res.status(404).json({error:'user not found'});
  const now = new Date().toISOString();
  await db.run('INSERT INTO receipts(user_id,filename,amount,status,created_at) VALUES(?,?,?,?,?)',[u.id, req.file.filename, parseFloat(SUBS_PRICE), 'pending', now]);
  res.json({message:'Comprovante enviado. Aguarde confirmação.'});
});

// admin login (simple)
app.post('/admin/login', async (req,res)=>{
  const {user,pass} = req.body;
  if(user===ADMIN_USER && pass===ADMIN_PASS){
    const token = genToken({admin:true,user:ADMIN_USER});
    return res.json({token});
  }
  res.status(401).json({error:'invalid'});
});

// admin: list receipts
app.get('/admin/receipts', async (req,res)=>{
  const auth = req.headers.authorization?.split(' ')[1];
  const t = verifyToken(auth);
  if(!t || !t.admin) return res.status(401).json({error:'admin required'});
  const rows = await db.all('SELECT r.*, u.email FROM receipts r LEFT JOIN users u ON u.id=r.user_id ORDER BY r.created_at DESC');
  res.json(rows);
});

// admin: confirm receipt
app.post('/admin/confirm', async (req,res)=>{
  const {id} = req.body;
  const auth = req.headers.authorization?.split(' ')[1];
  const t = verifyToken(auth);
  if(!t || !t.admin) return res.status(401).json({error:'admin required'});
  const rrec = await db.get('SELECT * FROM receipts WHERE id=?',[id]);
  if(!rrec) return res.status(404).json({error:'not found'});
  const expires = new Date(); expires.setDate(expires.getDate()+30);
  await db.run('UPDATE receipts SET status=? WHERE id=?',['paid', id]);
  await db.run('UPDATE users SET active=1, expires_at=? WHERE id=?',[expires.toISOString(), rrec.user_id]);
  res.json({message:'Usuário ativado'});
});

// stream endpoint - only active users
app.get('/api/stream/:id', async (req,res)=>{
  const auth = req.headers.authorization?.split(' ')[1];
  const user = auth ? verifyToken(auth) : null;
  if(!user) return res.status(401).end();
  const u = await db.get('SELECT * FROM users WHERE id=?',[user.id]);
  if(!u || u.active!==1) return res.status(403).json({error:'assinatura necessária'});
  const idp = Number(req.params.id);
  const r = await fetch(FUTEMAIS);
  const html = await r.text();
  const re = /<a[^>]+href=["']([^"']+)["'][^>]*>([^<]+)<\/a>/gi;
  let m; let cur=1; let origin=null; let title=null;
  while((m = re.exec(html)) !== null){
    if(cur===idp){ origin = m[1]; title = m[2].trim(); break; }
    cur++;
  }
  if(!origin) return res.status(404).json({error:'stream not found'});
  const token = jwt.sign({uid:u.id,gid:idp}, JWT_SECRET, {expiresIn:'10m'});
  const proxied = `/proxy/redirect?u=${encodeURIComponent(origin)}&t=${token}`;
  res.json({url: proxied, title});
});

// proxy redirect
app.get('/proxy/redirect', async (req,res)=>{
  const {u, t} = req.query;
  try{ jwt.verify(t, JWT_SECRET); }catch(e){ return res.status(403).end(); }
  return res.redirect(u);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('fut+ server running on', PORT));
